# Cambridge 640A — следующее изготовление, CN21 VH

Открыть 640A_PowerAmp.kicad_pro в KiCad 10.0.8 или совместимой версии.
Исходники совпадают с корнем репозитория. CN21 — VH; изготовленная ранее плата остаётся XH.
Подробности: ROUTING_REPORT.md. Виды: final_views. Проверки: validation.
Gerber в архив не включены.
