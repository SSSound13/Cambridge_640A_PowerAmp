import json,math,csv
from pathlib import Path
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch,Circle
root=Path(__file__).resolve().parent.parent; src=json.load(open(root/'audit/source_geometry.json')); data=json.load(open(root/'native_geometry.json')); fs=data['footprints']; plan=json.load(open(root/'placement_input.json'))['placements']; moving=set(plan); errors=[]
def near(a,b):return max(abs(x-y) for x,y in zip(a,b))<.00001
assert set(fs)==set(src)
for r,f in fs.items():
 if r not in moving and (not near(f['xy'],src[r]['xy']) or abs(f['angle']-src[r]['angle'])>.001):errors.append(['fixed',r])
 for p in f['pads']:
  old=next(x for x in src[r]['pads'] if x['number']==p['number'])
  if p['net']!=(old['net'][0] if old['net'] else ''):errors.append(['net',r,p['number']])
for r,rec in plan.items():
 if r!=rec['pair'][0]:continue
 a,b=[fs[q] for q in rec['pair']]
 if a['footprint']!=b['footprint'] or abs(a['angle']-b['angle'])>.001:errors.append(['pair',rec['pair']])
 for p in a['pads']:
  q=next(x for x in b['pads'] if x['number']==p['number'])
  if not near([q['xy'][0]-p['xy'][0],q['xy'][1]-p['xy'][1]],[98.9558,0]) or p['size']!=q['size'] or p['drill']!=q['drill']:errors.append(['pad symmetry',rec['pair'],p['number']])
polys={r:unary_union([Polygon(p).buffer(0) for p in f['polys'] if len(p)>2]) for r,f in fs.items()}
collisions=[]
for r in moving:
 for q in fs:
  if r==q or (q in moving and q<r):continue
  area=polys[r].intersection(polys[q]).area
  if area>1e-6:collisions.append([r,q,round(area,6)])
report={'footprints':len(fs),'moved_footprints':len(moving),'paired_groups':len(moving)//2,'fixed_footprints':len(fs)-len(moving),'errors':errors,'courtyard_intersections_involving_moved':collisions,'translation_mm':[98.9558,0]}
json.dump(report,open(root/'validation/placement.json','w'),indent=2);print(json.dumps(report))
with open(root/'placement.csv','w') as out:
 w=csv.writer(out);w.writerow(['Reference','Pair','X_anchor_mm','Y_anchor_mm','Angle_deg','X_body_center_mm','Y_body_center_mm','Footprint','Pad_drills_mm'])
 for r in sorted(moving):
  f=fs[r];rec=plan[r];w.writerow([r,'/'.join(rec['pair']),*f['xy'],f['angle'],*(rec['xy'] if rec['radius'] else ['','']),f['footprint'],';'.join(p['number']+':'+str(p['drill'][0]) for p in f['pads'])])
fig,axes=plt.subplots(1,2,figsize=(18,12))
for ax,anchor,title in zip(axes,[(73.5809,61.068),(172.5367,61.068)],['LEFT CHANNEL','RIGHT CHANNEL']):
 for r,f in fs.items():
  x,y=[v-a for v,a in zip(f['xy'],anchor)]
  if not(-15<x<60 and -15<y<50):continue
  color='#146fba' if r in moving else '#b3b3b3'
  for p in f['polys']:ax.add_patch(Patch([(x-anchor[0],y-anchor[1]) for x,y in p],fill=False,edgecolor=color,lw=.8))
  if r in moving and plan[r]['radius']:
   xy=[v-a for v,a in zip(plan[r]['xy'],anchor)];ax.add_patch(Circle(xy,plan[r]['radius'],fc='#f9d77c',ec='#b97700',alpha=.8))
  for p in f['pads']:
   xx,yy=[v-a for v,a in zip(p['xy'],anchor)];ax.add_patch(Circle((xx,yy),p['drill'][0]/2,fc='white',ec=color,lw=.6))
  ax.text(x,y-1.5,r,fontsize=6,color='#102c40' if r in moving else '#8a8a8a',ha='center')
 ax.set(xlim=(-12,57),ylim=(45,-12),aspect='equal',title=title,xlabel='Local X, mm',ylabel='Local Y, mm');ax.set_xticks(range(-10,60,5));ax.set_yticks(range(-10,46,5));ax.grid(alpha=.2)
fig.suptitle('Cambridge Audio 640A / v2 placement plan — UNROUTED\nBlue: paired placement changes | Grey: fixed existing parts | Yellow: reserved capacitor bodies',fontsize=14)
fig.tight_layout();fig.savefig(root/'placement_channels.png',dpi=180);fig.savefig(root/'placement_channels.pdf');plt.close(fig)
fig,ax=plt.subplots(figsize=(15,9))
for r,f in fs.items():
 color='#146fba' if r in moving else '#aaaaaa'
 for p in f['polys']:ax.add_patch(Patch(p,fill=False,edgecolor=color,lw=.45))
 if r in moving and plan[r]['radius']:ax.add_patch(Circle(plan[r]['xy'],plan[r]['radius'],fc='#f9d77c',ec='#b97700'))
 if r in moving:ax.text(*f['xy'],r,fontsize=4,ha='center')
x0,y0,x1,y1=data['edge_bbox'];ax.set(xlim=(x0-2,x1+2),ylim=(y1+2,y0-2),aspect='equal',xlabel='Board X, mm',ylabel='Board Y, mm',title='640A v2 — placement overview / UNROUTED');ax.grid(alpha=.15);fig.tight_layout();fig.savefig(root/'placement_overview.pdf');fig.savefig(root/'placement_overview.png',dpi=160)
