import pcbnew,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
b=pcbnew.LoadBoard(str(root/'640A_PowerAmp.kicad_pcb'));out={}
for f in b.GetFootprints():
 f.BuildCourtyardCaches();poly=f.GetCourtyard(pcbnew.F_CrtYd);polys=[]
 for i in range(poly.OutlineCount()):
  q=poly.Outline(i);polys.append([[pcbnew.ToMM(q.CPoint(j).x),pcbnew.ToMM(q.CPoint(j).y)] for j in range(q.PointCount())])
 pads=[]
 for p in f.Pads():
  pads.append({'number':p.GetNumber(),'xy':[pcbnew.ToMM(p.GetPosition().x),pcbnew.ToMM(p.GetPosition().y)],'size':[pcbnew.ToMM(p.GetSize().x),pcbnew.ToMM(p.GetSize().y)],'drill':[pcbnew.ToMM(p.GetDrillSize().x),pcbnew.ToMM(p.GetDrillSize().y)],'net':p.GetNetname(),'shape':int(p.GetShape())})
 graphics=[]
 for item in f.GraphicalItems():
  if item.GetLayer()!=pcbnew.F_Fab or not hasattr(item,'GetShape'):continue
  kind=int(item.GetShape()); rec={'kind':kind}
  for prop in ['Start','End','Center']:
   if hasattr(item,'Get'+prop):
    pt=getattr(item,'Get'+prop)();rec[prop.lower()]=[pcbnew.ToMM(pt.x),pcbnew.ToMM(pt.y)]
  graphics.append(rec)
 out[f.GetReference()]={'xy':[pcbnew.ToMM(f.GetPosition().x),pcbnew.ToMM(f.GetPosition().y)],'angle':f.GetOrientationDegrees(),'footprint':f.GetFPIDAsString(),'value':f.GetValue(),'uuid':f.m_Uuid.AsString(),'polys':polys,'pads':pads,'fab':graphics}
edge=b.GetBoardEdgesBoundingBox()
json.dump({'footprints':out,'edge_bbox':[pcbnew.ToMM(edge.GetLeft()),pcbnew.ToMM(edge.GetTop()),pcbnew.ToMM(edge.GetRight()),pcbnew.ToMM(edge.GetBottom())],'shape_enums':{name:int(getattr(pcbnew,name)) for name in ['S_SEGMENT','S_RECT','S_CIRCLE','S_ARC']}},open(root/'native_geometry.json','w'),indent=2)
print('Exported',len(out),'footprints')
